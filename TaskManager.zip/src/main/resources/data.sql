insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10001, 'Mohit', 'Get Sping Boot Certified', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10002, 'Mohit', 'Get HTML Certified', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10003, 'Mohit', 'Get CSS Certified', CURRENT_DATE(), false);

insert into todo (ID, USERNAME, DESCRIPTION, TARGET_DATE, DONE)
values(10004, 'Mohit', 'Get Javascript Certified', CURRENT_DATE(), false);